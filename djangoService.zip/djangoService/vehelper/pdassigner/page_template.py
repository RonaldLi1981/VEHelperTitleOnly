# -*- coding: utf-8 -*-
"""
Created on Thu Aug 23 19:52:57 2018

@author: LENOVO
"""

class page:
#    page_body_a = '''<form action="servlet/UploadFile"   method="post"   enctype="multipart/form-data">
#<input type="file" name="file1" id="file1" />
#<input type="submit" value="上传" />
#</form>'''

    page_body_b = '''<form action="proceed_pd_titles"   method="post"   enctype="multipart/form-data"><br/>
    <input type="submit" value="Assign to Teams" /><br/><br/>
    Output Format : 
    <input type="radio" name="output_format" value="TeamOnly" checked="checked">Team Only
    <input type="radio" name="output_format" value="REPDTEST">REPDTEST Format
    <input type="text" name="release_name" value="Input Release Name Here" size="40">
    <a href="./rqm_importing_cfg" style="text-decoration:none;color:blue">click here to get RQM Importing CFG</a>
    <br/><br/>
    <textarea name="pdtitles" cols="150" rows="40" style="overflow-x:hidden;background-color:FFFFCE"/>
EXAMPLE:

12345 - [MTA MIB] The default value of MIB ietfPktcSigDevCidMode is dtAsETS

*23456 - [GUI][mso] Unable to configure "Public Wi-Fi Network & HS Port Forwarding" settings in GUI  

*PD10000 - [BSoD]The modem doesn't report eSAFE Host Capability TLV5.18 to CMTS in a Registration Request message.

*PD 100001 - [RDKB][Puma7][MoCA]MoCA privacy can't be enabled/disabled and MoCA password can't be configured via GUI

*PD 10111 - [CT][Security][DDoS] SNMP has no response when wan0 under DS direction IPv4 flooding attack

pd 54321 - [WiFi][RDKB]Failed to set 5G WiFi operation mode to a,n, error code 9007 return
    </textarea>
</form>'''

    #'''<a onclick="uploadfile1();" style="cursor: pointer; display: inline-block;background-color: aqua">XMLHttpRequet上传</a>'''
 

#    page_body_js = '''<script>
#      function uploadfile1() {
#            var form = new FormData();
#            form.append('user', document.getElementById('user').value);
# 
#            var fileobj = document.getElementById('img').files[0];
#            form.append('img', fileobj);
# 
#            var xhr = new XMLHttpRequest();
#            xhr.onreadystatechange = function () {
#                if(xhr.readyState == 4){
#                    var data = xhr.responseText;
#                    console.log(data)
#                }
#            };
#            xhr.open('post', '/upload/', true)
#            xhr.send(form);
#        }
#</script>'''